Remove EXIF v1.0 — Moosh Massacre <gustavo@mooshmassacre.studio>

Double-click "Install Remove EXIF.command" to install the Finder Quick Action and its script. If macOS blocks the first launch, Control-click the installer and choose Open.

Installed locations:
~/Library/Application Support/Remove EXIF/Remove_EXIF.command
~/Library/Services/Remove EXIF.workflow

The action processes selected JPEG and PNG images in place, without recompression. It is silent on success. Existing installed files are backed up under ~/Library/Application Support/Remove EXIF/Backups.

No administrator password or external software is required. If the action does not appear immediately, restart Finder or sign out and back in.

MIT License: see LICENSE.
